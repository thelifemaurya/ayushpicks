export const BRAND = "AyushPicks";
export const INSTAGRAM = "https://www.instagram.com/ayushpicks";
export const SITE = (process.env.NEXT_PUBLIC_SITE_URL || "https://ayushpicks.com").replace(/\/$/, "");
export const ADMIN_EMAIL = "ayushmourya590@gmail.com";
export const SB_URL = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
export const SB_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";
export const BUCKET = "ksnatic-product-images";
