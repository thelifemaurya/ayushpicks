import type { Metadata, Viewport } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import { SITE } from "@/lib/site";
import { AuthRedirect } from "@/components/AuthRedirect";
const inter = Inter({ subsets: ["latin"], display: "swap", variable: "--font-inter" });
const display = Playfair_Display({ subsets: ["latin"], display: "swap", variable: "--font-display", weight: ["500", "600"] });
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#FBF9F5", interactiveWidget: "resizes-content" };
export const metadata: Metadata = {
  metadataBase: new URL(SITE),
  title: { default: "AyushPicks — Discover, Compare & Decide on Products Worth Buying", template: "%s | AyushPicks" },
  description: "AyushPicks helps you understand what products actually do, compare alternatives and decide what's worth buying, before you visit a retailer.",
  applicationName: "AyushPicks",
  openGraph: { siteName: "AyushPicks", type: "website", locale: "en_IN" },
  twitter: { card: "summary_large_image" },
  verification: process.env.NEXT_PUBLIC_GSC_VERIFICATION ? { google: process.env.NEXT_PUBLIC_GSC_VERIFICATION } : undefined,
};
export default function Root({ children }: { children: React.ReactNode }) {
  return <html lang="en" className={`${inter.variable} ${display.variable}`}><body><AuthRedirect />{children}</body></html>;
}
