import type { MetadataRoute } from "next";
import { SITE } from "@/lib/site";
import { getProducts } from "@/lib/products";
import { slugify } from "@/lib/data";
export const revalidate = 3600;
export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = await getProducts();
  const cats = [...new Set(products.map((p) => p.category))];
  return [
    ...["", "/search", "/compare", "/about", "/contact", "/privacy", "/terms"].map((p) => ({ url: `${SITE}${p}` })),
    ...cats.map((c) => ({ url: `${SITE}/category/${slugify(c)}` })),
    ...products.map((p) => ({ url: `${SITE}/product/${p.slug}`, lastModified: p.updatedAt })),
  ];
}
