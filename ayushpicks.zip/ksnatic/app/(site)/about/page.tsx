import type { Metadata } from "next";
import Link from "next/link";
import { Info } from "@/components/Info";
export const metadata: Metadata = { title: "About AyushPicks", description: "AyushPicks is a product discovery platform. Learn how we pick products, how we write verdicts and how we earn money.", alternates: { canonical: "/about" } };
export default function About() {
  return (<Info title="About AyushPicks">
    <p>AyushPicks helps you work out whether a product is worth buying. We don&apos;t make, stock, sell or ship anything. We explain what a product does, show its strengths and limitations, compare alternatives, and then send you to a retailer if you decide to buy.</p>
    <h2 id="how">How it works</h2>
    <p>Discover products, understand what they offer, compare alternatives, decide with the pros and limitations in front of you, then buy from the retailer. See the <Link href="/#how">five steps</Link> on the home page.</p>
    <h2 id="editorial">Editorial approach</h2>
    <p>We show limitations next to strengths and avoid hype. Our verdicts are our own opinion and we say who a product is good for and who should skip it.</p>
    <h2>How we earn</h2>
    <p>Some retailer links are affiliate links, so we may earn a commission if you buy. This never changes our verdicts or ratings.</p>
  </Info>);
}
